const quotes = [
{
name: 'Controlpee',
quote: 'Knowledge is power but with computer you are more powerful'
},
{
name: 'Martineze',
quote: 'If you want to be happy be!'
},
{
 name: 'Jon F. Kennedy',
 quote: 'Those who dare to fail misrably can achieve greatly!'   
},
{
name: 'Abraham Lincoln',
quote: 'Am a success today, because i have a friend who believed in me and i dont have the heart to let him down!'
},
{
name: 'Joseph King',
quote: 'Get busy living or get busy dying'
},
{
name: 'Leonard Da Vinci',
quote: 'It had long since come to my attention that people with accomplishment ' +
'rarely sat back and let things happend to them, they went out and happened things '
}
]


const quoteBtn = document.querySelector('#quoteBtn');
const quoteAuthor = document.querySelector('.quoteAuthor');
const quote = document.getElementById('quote');


quoteBtn.addEventListener('click', () => {
    // call displayQuote function

    displayQuote();
});

// create displayQuote function

const displayQuote = () => {

let number = Math.floor(Math.random()*quotes.length);

quoteAuthor.textContent = quotes[number].name;
quote.innerHTML = quotes[number].quote;
}